$(function(){
	// 판매 템플릿
	$(".template_default").click(function(){
		location.href = "reserveForm";	 //판매랑 예매 동일 판매의 원래 이름은 defaultForm
	});
	// 배달 템플릿
	$(".template_delivery").click(function(){
		location.href = "deliveryForm";
	});
	// 예매 템플릿
	$(".template_reserve").click(function(){
		location.href = "reserveForm";
	});
	// 숙박  템플릿
	$(".template_lodge").click(function(){
		location.href = "reserveForm";  // lodgeForm
	});
});