$(function(){
	
	/*이슈쓰기 버튼 */
	$(".issue_addIssuebtn").click(function(){
		location.href="addIssue";
		
		});

	
});