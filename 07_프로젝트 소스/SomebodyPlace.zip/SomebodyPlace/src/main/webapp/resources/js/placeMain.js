
$(function(){
	// 메인화면 로그인버튼
	$(".placeMain_addBtn").click(function(){
			location.href="placeAddForm";
	});
});
