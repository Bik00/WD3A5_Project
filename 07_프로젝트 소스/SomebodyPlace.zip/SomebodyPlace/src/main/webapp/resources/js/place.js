$(function(){
	// 플레이스 글쓰기 버튼
	$(".postForm_btn").click(function(){
		location.href = "postForm";
	});
	
	$(".placeManager_btn").click(function(){
		location.href = "placeManager";
	});
	
	
	
	
});