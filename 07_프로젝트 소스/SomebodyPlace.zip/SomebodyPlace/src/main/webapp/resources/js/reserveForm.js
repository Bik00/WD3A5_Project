$(function(){
    function readURL(input) {
        if(input.files && input.files[0]) {
            var reader = new FileReader();  // 파일을 읽기위한 FileReader 객체 생성
            reader.onload = function(e) {   // 파일 읽기를 성공했을 때 호출되는 이벤트 핸들러
                var img = new Image();      // 이미지 태그 생성
                img.src = e.target.result;  // 이미지 태그 src 속성에 file내용을 지정
                
                img.width = $(".reserve_fileBox label").width();
                img.onload = function(){
                    console.log(img.height);
                    $('.reserve_fileBox').height(img.height);
                };
                
                $('.reserveForm_img').html('');
                $('.reserveForm_img').append(img);
            }
            reader.readAsDataURL(input.files[0]);   // file내용을 읽어 dataURL 형식의 문자열로 저장
        }
    }
    $('#reserveForm_ImgUpload').change(function(){   // file양식으로 이미지를 선택되었을 때 처리
        readURL(this);
    });


    // 추가옵션박스 생성
    $(".reserveForm_optionBtn").click(function(){
        var optionBox = '<div class="reserveForm_optionBox form-inline">' +
                        '<span><input type="text" placeholder="추가옵션명" class="form-control">' +
                        '<span style="float:right" class="reserve_optionBox_del"><p>x</p></span></span><br>' +
                        '<input type="text" placeholder="추가옵션" class="form-control">' +
                        '<span style="float:right"><input type="text" class="form-control">원<span class="optionBox_plus"><p>+</p></span></span>' +
                        '</div>';
        $(".reserveForm_options").append(optionBox);
    });
    // 추가옵션박스 삭제버튼 표시
    $(document).on("mouseover",".reserveForm_optionBox", function(){
         $(this).find($(".reserve_optionBox_del")).show();
         $(this).find($(".reserve_optionBox_del")).css("display", "inline-block");
         
    });
    // 추가옵션박스 삭제버튼 표시 없애기
    $(document).on("mouseout",".reserveForm_optionBox", function(){
         $(this).find($(".reserve_optionBox_del")).hide();
    });
    // 추가옵션박스 삭제
    $(document).on("click", ".reserve_optionBox_del", function(){
        $(this).parent().parent().remove();
    });
    // 추가옵션 하나 추가
    $(document).on("click", ".optionBox_plus", function(){
        var option = '<input type="text" placeholder="추가옵션" class="form-control">' +
                    '<span style="float:right"><input type="text" class="form-control">원<span class="optionBox_minus"><p>-</p></span></span>' ;
        $(this).parent().parent().append(option);
    });
    // 추가옵션 하나 삭제
    $(document).on("click", ".optionBox_minus", function(){
        $(this).parent().prev().remove();
        $(this).parent().remove();
    });

});