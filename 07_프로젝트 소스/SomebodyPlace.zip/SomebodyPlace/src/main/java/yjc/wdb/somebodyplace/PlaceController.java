package yjc.wdb.somebodyplace;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class PlaceController {
	@RequestMapping(value="place", method=RequestMethod.GET)
	public String place(Model model){
		model.addAttribute("cont", "place/place.jsp");
		return "index";
	}
	
	@RequestMapping(value="postForm", method=RequestMethod.GET)
	public String postForm(Model model){
		model.addAttribute("type", "reserveForm.jsp");
		model.addAttribute("cont", "place/postForm.jsp");
		
		return "index";
	}
	
	@RequestMapping(value="deliveryForm", method=RequestMethod.GET)
	public String deliveryForm(Model model){
		model.addAttribute("type", "deliveryForm.jsp");
		model.addAttribute("cont", "place/postForm.jsp");
		
		return "index";
	}
	
	@RequestMapping(value="reserveForm", method=RequestMethod.GET)
	public String reserveForm(Model model){
		model.addAttribute("type", "reserveForm.jsp");
		model.addAttribute("cont", "place/postForm.jsp");
		
		return "index";
	}
	
	@RequestMapping(value="lodgeForm", method=RequestMethod.GET)
	public String lodgeForm(Model model){
		model.addAttribute("type", "lodgeForm.jsp");
		model.addAttribute("cont", "place/postForm.jsp");
		
		return "index";
	}
	
	@RequestMapping(value="placeMain", method=RequestMethod.GET)
	public String placeMain(Model model){
		model.addAttribute("cont", "place/placeMain.jsp");
		
		return "index";
	}
	
	@RequestMapping(value="placeAddForm", method=RequestMethod.GET)
	public String placeAddForm(Model model){
		model.addAttribute("cont", "place/placeAddForm.jsp");
		
		return "index";
	}
	
	
	
}
