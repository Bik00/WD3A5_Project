package yjc.wdb.somebodyplace;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ManagerController {
	@RequestMapping(value="placeManager", method=RequestMethod.GET)
	public String mypage(Model model){
		model.addAttribute("cont", "place/placeManager.jsp");
		return "index";
	}
	
	@RequestMapping(value="placemodify", method=RequestMethod.GET)
	public String placemodify(Model model){
		model.addAttribute("cont", "manager/modifyPlace.jsp");
		return "index";
	}
	
	@RequestMapping(value="requestList", method=RequestMethod.GET)
	public String requestList(Model model){
		model.addAttribute("cont", "manager/requestList.jsp");
		return "index";
	}
	
	@RequestMapping(value="addBusiness", method=RequestMethod.GET)
	public String 	addBusiness(Model model){
		model.addAttribute("cont", "manager/addBusiness.jsp");
		return "index";
	}
	@RequestMapping(value="categorySetting", method=RequestMethod.GET)
	public String 	categoryChange(Model model){
		model.addAttribute("cont", "manager/categorySetting.jsp");
		return "index";
	}
	
	@RequestMapping(value="currentBudget", method=RequestMethod.GET)
	public String 	currentBudget(Model model){
		model.addAttribute("cont", "manager/currentBudget.jsp");
		return "index";
	}
	
	
}
