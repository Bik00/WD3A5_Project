package yjc.wdb.somebodyplace;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class IssueController {
	@RequestMapping(value="issue", method=RequestMethod.GET)
	public String issue(Model model){
		model.addAttribute("cont", "issue/issue.jsp");
		return "index";
	}
	
	
	@RequestMapping(value="addIssue", method=RequestMethod.GET)
	public String modifyForm(Model model){
		model.addAttribute("cont", "issue/addIssue.jsp");
		return "index";
	}
}
