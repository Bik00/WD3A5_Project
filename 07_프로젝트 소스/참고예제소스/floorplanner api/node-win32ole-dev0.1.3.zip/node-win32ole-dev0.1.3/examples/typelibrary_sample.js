var win32ole = require('win32ole');
win32ole.print('typelibrary_sample\n');
