package yjc.wdb.somebodyplace.bean;


public class Detail {
	private int detail_code;
	private int option_code;
	private String detail_name;
	private int additional_price;
	
	public int getDetail_code() {
		return detail_code;
	}
	public void setDetail_code(int detail_code) {
		this.detail_code = detail_code;
	}
	public int getOption_code() {
		return option_code;
	}
	public void setOption_code(int option_code) {
		this.option_code = option_code;
	}
	public int getAdditional_price() {
		return additional_price;
	}
	public void setAdditional_price(int additional_price) {
		this.additional_price = additional_price;
	}
	public String getDetail_name() {
		return detail_name;
	}
	public void setDetail_name(String detail_name) {
		this.detail_name = detail_name;
	}

}
