package yjc.wdb.somebodyplace.bean;

public class Auto {
	private int auto_code;
	private String auto_title;
	private String auto_content;
	private String member_nickname;
	
	public int getAuto_code() {
		return auto_code;
	}
	public void setAuto_code(int auto_code) {
		this.auto_code = auto_code;
	}
	public String getAuto_title() {
		return auto_title;
	}
	public void setAuto_title(String auto_title) {
		this.auto_title = auto_title;
	}
	public String getAuto_content() {
		return auto_content;
	}
	public void setAuto_content(String auto_content) {
		this.auto_content = auto_content;
	}
	public String getMember_nickname() {
		return member_nickname;
	}
	public void setMember_nickname(String member_nickname) {
		this.member_nickname = member_nickname;
	}
}
