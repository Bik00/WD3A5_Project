package yjc.wdb.somebodyplace.bean;

public class Option {
	private int option_code;
	private int product_code;
	private String option_name;
	
	public int getOption_code() {
		return option_code;
	}
	public void setOption_code(int option_code) {
		this.option_code = option_code;
	}
	public int getProduct_code() {
		return product_code;
	}
	public void setProduct_code(int product_code) {
		this.product_code = product_code;
	}
	public String getOption_name() {
		return option_name;
	}
	public void setOption_name(String option_name) {
		this.option_name = option_name;
	}
}
