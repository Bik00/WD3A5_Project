package yjc.wdb.somebodyplace.bean;

public class Mcate {
	private int mcate_code;
	private String mcate_name;
	public String getMcate_name() {
		return mcate_name;
	}
	public void setMcate_name(String mcate_name) {
		this.mcate_name = mcate_name;
	}
	public int getMcate_code() {
		return mcate_code;
	}
	public void setMcate_code(int mcate_code) {
		this.mcate_code = mcate_code;
	}
}
