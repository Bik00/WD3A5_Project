package yjc.wdb.somebodyplace.bean;

public class PostContent {
	private int post_content_code;
	private int post_code;
	private String content;
	
	public int getPost_content_code() {
		return post_content_code;
	}
	public void setPost_content_code(int post_content_code) {
		this.post_content_code = post_content_code;
	}
	public int getPost_code() {
		return post_code;
	}
	public void setPost_code(int post_code) {
		this.post_code = post_code;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
