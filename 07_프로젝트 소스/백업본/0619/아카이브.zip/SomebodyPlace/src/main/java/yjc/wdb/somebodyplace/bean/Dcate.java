package yjc.wdb.somebodyplace.bean;

public class Dcate {
	private int dcate_code;
	private int mcate_code;
	private String dcate_name;
	public int getDcate_code() {
		return dcate_code;
	}
	public void setDcate_code(int dcate_code) {
		this.dcate_code = dcate_code;
	}
	public int getMcate_code() {
		return mcate_code;
	}
	public void setMcate_code(int mcate_code) {
		this.mcate_code = mcate_code;
	}
	public String getDcate_name() {
		return dcate_name;
	}
	public void setDcate_name(String dcate_name) {
		this.dcate_name = dcate_name;
	}
}
