package yjc.wdb.somebodyplace.bean;

public class Post {
	private int post_code;
	private int board_code;
	private String hashtag;
	private int mcate_code;
	private int dcate_code;
	private int product_code;
	private String type;
	
	public int getPost_code() {
		return post_code;
	}
	public void setPost_code(int post_code) {
		this.post_code = post_code;
	}
	public int getBoard_code() {
		return board_code;
	}
	public void setBoard_code(int board_code) {
		this.board_code = board_code;
	}
	public String getHashtag() {
		return hashtag;
	}
	public void setHashtag(String hashtag) {
		this.hashtag = hashtag;
	}
	public int getMcate_code() {
		return mcate_code;
	}
	public void setMcate_code(int mcate_code) {
		this.mcate_code = mcate_code;
	}
	public int getDcate_code() {
		return dcate_code;
	}
	public void setDcate_code(int dcate_code) {
		this.dcate_code = dcate_code;
	}
	public int getProduct_code() {
		return product_code;
	}
	public void setProduct_code(int product_code) {
		this.product_code = product_code;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
