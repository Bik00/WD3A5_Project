<?php

class Floorplanner_Exception extends Exception {
	

	public function __construct($response) {
		print_r($response);
	}
}

?>