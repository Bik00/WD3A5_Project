<html>
<head>
	<title> Floorplanner embedding POC </title>
	
</head>

<body>

<iframe src="http://www.floorplanner.com/projects/2/embed" width="600" height="400">
	Floorplanner will load here
</iframe>
	
</body>
</html>