<?php

  class RoomstylerRoomRenderMethods extends RoomstylerMethodBase {}

?>
