<?php

  class RoomstylerComment extends RoomstylerModelBase {}

?>
