<?php

  class RoomstylerMaterial extends RoomstylerModelBase {}

?>
