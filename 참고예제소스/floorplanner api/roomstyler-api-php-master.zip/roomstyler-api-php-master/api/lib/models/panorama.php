<?php

  class RoomstylerRoomPanorama extends RoomstylerModelBase {}

?>
