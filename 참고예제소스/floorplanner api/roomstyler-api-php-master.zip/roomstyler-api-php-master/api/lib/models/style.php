<?php

  class RoomstylerStyle extends RoomstylerModelBase {}

?>
