<?php

  class RoomstylerRoomRender extends RoomstylerModelBase {}

?>
