<?php

  class RoomstylerContestVote extends RoomstylerModelBase {}

?>
