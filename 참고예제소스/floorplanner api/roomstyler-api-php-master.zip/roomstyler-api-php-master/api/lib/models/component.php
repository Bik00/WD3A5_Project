<?php

  class RoomstylerComponent extends RoomstylerModelBase {}

?>
