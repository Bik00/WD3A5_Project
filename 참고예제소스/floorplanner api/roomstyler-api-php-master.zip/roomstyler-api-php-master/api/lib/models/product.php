<?php

  class RoomstylerProduct extends RoomstylerModelBase {}

?>
