<?php

  class RoomstylerCollectionItem extends RoomstylerModelBase {}

?>
