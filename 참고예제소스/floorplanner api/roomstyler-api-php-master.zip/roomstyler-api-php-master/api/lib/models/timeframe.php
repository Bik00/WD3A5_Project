<?php

  class RoomstylerTimeframe extends RoomstylerModelBase {}

?>
